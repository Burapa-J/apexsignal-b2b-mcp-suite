# B2B Account Intelligence & Outbound Dossier

## 1. Executive Summary
| Company | Domain | Outbound Readiness | Hiring Signal | Primary Contact | Recommended Email | Deliverability |
|---|---|---|---|---|---|---|
| {{companyName}} | `{{domain}}` | **{{outboundReadinessScore}}/100** ({{tier}}) | `{{hiringSignalTier}}` ({{totalMatchingJobs}} open roles) | {{fullName}} ({{role}}) | `{{recommendedEmail}}` | `{{deliverabilityRisk}}` risk ({{mailProvider}}) |

---

## 2. Domain & Tech Stack Intelligence
- **Mail Infrastructure:** `hasMx={{hasMx}}` | Provider: `{{mailProvider}}` | SPF: `{{hasSpf}}` | DMARC: `{{hasDmarc}}`
- **Detected Tech Stack:** {{techStack}}
- **Public Channels:** LinkedIn: {{linkedinUrl}} | GitHub: {{githubUrl}} | Public Emails: {{publicEmails}}

---

## 3. Live ATS Hiring Intent (`{{atsBoard}}`)
- **Total Matching Open Roles:** {{totalMatchingJobs}} ({{remoteJobsCount}} remote)
- **Top Hiring Departments:** {{topDepartments}}
- **Key Open Positions:**
  1. **{{jobTitle1}}** — {{jobDepartment1}} ({{jobLocation1}}) -> {{jobApplyUrl1}}
  2. **{{jobTitle2}}** — {{jobDepartment2}} ({{jobLocation2}}) -> {{jobApplyUrl2}}

---

## 4. Signal-Backed Outbound Email Draft
**To:** `{{recommendedEmail}}` ({{fullName}}, {{role}} at {{companyName}})  
**Subject:** Scaling {{topDepartment}} at {{companyName}} ({{jobTitle1}})

Hi {{firstName}},

Noticed {{companyName}} currently has {{totalMatchingJobs}} open roles on {{atsProvider}}—specifically looking to scale {{topDepartment}} with roles like *{{jobTitle1}}*.

Given your stack ({{techStack}}), teams scaling at this pace usually hit bottlenecks around [insert user value proposition].

Would it be useful if I shared a quick 2-minute breakdown of how we help {{topDepartment}} teams accelerate that ramp?

Best regards,  
[Your Name]
