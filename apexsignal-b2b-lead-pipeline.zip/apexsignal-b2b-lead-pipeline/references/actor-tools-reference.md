# ApexSignal B2B Intelligence Suite — MCP Tool Reference

All 5 Actors are hosted on Apify Store (`https://apify.com/apexsignal`) and exposed via Apify's official Streamable HTTP / SSE MCP Server (`https://mcp.apify.com`).

---

## 1. `apexsignal/b2b-hiring-intent-lead-pipeline`
**Store URL:** `https://apify.com/apexsignal/b2b-hiring-intent-lead-pipeline`  
**Purpose:** All-in-One Composite B2B Pipeline combining ATS job scraping, domain DNS/MX & tech stack enrichment, and executive email discovery in a single call.

### Input Schema
```json
{
  "targets": [
    {
      "domain": "cloudflare.com",
      "companyName": "Cloudflare",
      "atsBoard": "greenhouse:cloudflare",
      "executives": [
        { "fullName": "Matthew Prince", "role": "CEO" }
      ]
    }
  ],
  "departmentFilter": "Engineering",
  "keywordFilter": "Security",
  "remoteOnly": false,
  "maxJobsPerCompany": 5,
  "maxItems": 10
}
```

### Key Output Fields
- `domain`, `companyName`, `outboundReadinessScore` (`0–100`), `hiringSignalTier` (`"high" | "moderate" | "low" | "none"`)
- `domainEnrichment`: `{ title, emails, phones, socialLinks, techStack, hasMx, mailProvider, hasSpf, hasDmarc, leadQualityScore }`
- `hiringSummary`: `{ board, provider, totalMatchingJobs, remoteJobsCount, topDepartments, sampleJobs }`
- `executiveLeads`: `Array<{ fullName, role, recommendedEmail, confidenceScore, deliverabilityRisk, candidateEmails }>`

---

## 2. `apexsignal/b2b-domain-contact-enricher`
**Store URL:** `https://apify.com/apexsignal/b2b-domain-contact-enricher`  
**Purpose:** Extract public emails, phone numbers, social links (LinkedIn, X/Twitter, GitHub, YouTube, Facebook, Instagram), DNS MX/SPF/DMARC records, and tech stack fingerprints from corporate domains.

### Input Schema
```json
{
  "domains": ["apify.com", "cloudflare.com"],
  "maxPagesPerDomain": 2,
  "verifyDns": true,
  "maxItems": 10
}
```

### Key Output Fields
- `domain`, `url`, `title`, `description`
- `emails` (`string[]`), `phones` (`string[]`), `socialLinks` (`Record<string, string>`)
- `techStack` (`string[]`), `hasMx` (`boolean`), `mxRecords` (`string[]`), `mailProvider` (`string`), `hasSpf` (`boolean`), `hasDmarc` (`boolean`)
- `leadQualityScore` (`0–100`), `scrapedAt` (`ISO-8601`)

---

## 3. `apexsignal/ats-career-job-listing-api`
**Store URL:** `https://apify.com/apexsignal/ats-career-job-listing-api`  
**Purpose:** Direct JSON API extraction of active job postings from Greenhouse (`greenhouse:<slug>`), Lever (`lever:<slug>`), and Ashby (`ashby:<slug>`) without browser overhead.

### Input Schema
```json
{
  "boards": ["greenhouse:cloudflare", "greenhouse:stripe"],
  "departmentFilter": "Engineering",
  "keywordFilter": "AI",
  "remoteOnly": false,
  "maxItems": 25
}
```

### Key Output Fields
- `provider` (`"greenhouse" | "lever" | "ashby"`), `companySlug`, `jobId`, `title`, `department`, `location`
- `isRemote` (`boolean`), `employmentType`, `publishedAt`, `applyUrl`, `descriptionSnippet`
- `compensation`: `{ currency, minAmount, maxAmount, interval }` (when disclosed)

---

## 4. `apexsignal/b2b-company-lead-finder`
**Store URL:** `https://apify.com/apexsignal/b2b-company-lead-finder`  
**Purpose:** Combine firmographic domain enrichment with executive email pattern generation (`first@`, `first.last@`, `flast@`) and real-time DNS MX/SPF/DMARC verification.

### Input Schema
```json
{
  "companies": [
    {
      "domain": "apify.com",
      "companyName": "Apify",
      "executives": [
        { "fullName": "Jan Curn", "role": "CEO" }
      ]
    }
  ],
  "maxItems": 10
}
```

### Key Output Fields
- `domain`, `companyName`, `fullName`, `role`, `recommendedEmail`, `confidenceScore` (`0–100`)
- `deliverabilityRisk` (`"low" | "medium" | "high"`), `mailProvider`, `hasMx`, `hasSpf`, `hasDmarc`
- `publicCompanyEmails` (`string[]`), `socialLinks`, `techStack`, `candidateEmails` (`string[]`)

---

## 5. `apexsignal/bulk-email-mx-verifier`
**Store URL:** `https://apify.com/apexsignal/bulk-email-mx-verifier`  
**Purpose:** High-speed bulk email hygiene and deliverability verification via live DNS MX, SPF, DMARC, disposable provider detection, and role-account classification.

### Input Schema
```json
{
  "emails": ["support@apify.com", "founder@stripe.com"],
  "checkDns": true,
  "maxItems": 100
}
```

### Key Output Fields
- `email`, `domain`, `syntaxValid` (`boolean`), `hasMx` (`boolean`), `mxRecords` (`string[]`)
- `mailProvider` (`string`), `hasSpf` (`boolean`), `hasDmarc` (`boolean`)
- `isDisposable` (`boolean`), `isFreeMail` (`boolean`), `isRoleAccount` (`boolean`)
- `qualityScore` (`0–100`), `deliverabilityStatus` (`"deliverable" | "risky" | "undeliverable"`)
