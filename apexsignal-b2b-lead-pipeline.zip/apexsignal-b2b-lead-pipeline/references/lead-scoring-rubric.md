# B2B Hiring-Intent & Outbound Readiness Scoring Rubric

Use this deterministic 100-point rubric to interpret `outboundReadinessScore`, `leadQualityScore`, and `confidenceScore` returned by the `@apexsignal` MCP tools and recommend the right outreach action.

---

## 1. Composite Outbound Readiness Breakdown (`0–100` Points)

| Signal Dimension | Max Points | Criteria |
|---|---|---|
| **Domain & Mail Infrastructure (`b2b-domain-contact-enricher`)** | **40 pts** | Valid DNS MX records (`+15`), strict SPF/DMARC configuration (`+10`), public contact emails/phones/social links discovered (`+10`), active web tech stack fingerprinted (`+5`). |
| **Live ATS Hiring Velocity (`ats-career-job-listing-api`)** | **30 pts** | Active job openings matched on Greenhouse/Lever/Ashby: `>= 10` roles (`+30`, `hiringSignalTier: "high"`), `3–9` roles (`+20`, `"moderate"`), `1–2` roles (`+12`, `"low"`), `0` roles (`+0`, `"none"`). |
| **Executive Contact Confidence (`b2b-company-lead-finder`)** | **30 pts** | Verified corporate domain MX (`deliverabilityRisk: "low"` -> `+20`), matched corporate naming convention or public executive email (`+10`). |

---

## 2. Action Tiers for Sales & GTM Teams

### Tier A — High-Priority Immediate Outbound (`75–100` pts)
- **Characteristics:** `deliverabilityRisk: "low"`, active hiring across target departments (`hiringSignalTier: "high"` or `"moderate"`), and high-confidence executive email (`confidenceScore >= 80`).
- **Recommended Action:**
  - Enroll decision-maker in personalized 1-to-1 email + LinkedIn sequence immediately.
  - Anchor the opening line to the exact open roles returned in `hiringSummary.sampleJobs` and the detected `techStack`.

### Tier B — Warm Multi-Channel Nurture (`45–74` pts)
- **Characteristics:** Valid corporate MX (`hasMx: true`), either low current job count or only role/department contacts (`sales@`, `info@`, `press@`) available.
- **Recommended Action:**
  - Start with LinkedIn connection (`socialLinks.linkedin`) and value-first content before sending cold email.
  - Monitor ATS board monthly via `apexsignal/ats-career-job-listing-api` for new budget cycles.

### Tier C — Suppress / Do Not Email (`0–44` pts)
- **Characteristics:** `hasMx: false`, `isDisposable: true`, or `deliverabilityStatus: "undeliverable"`.
- **Recommended Action:**
  - **Do not send email.** Sending to domains without valid MX records harms domain reputation. Route to manual research or remove from campaign.
